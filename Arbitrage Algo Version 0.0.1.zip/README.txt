---------------------------------------------------------------------------------
-	Algorithm and architecture designed by Valentino Magniette-Bosseboeuf	-
-	Copyright 2024, all rights reserved					-
-	Allowed to be used for personal purposes only				-
-	Original hosting of the code on valentinomb.com				-
---------------------------------------------------------------------------------

Version 0.0.1
11th May 2024

This algorithm is designed on the basis of triangular arbitrage for the US Cryptocurrency Exchange Kraken which is owned by Payward, Inc.
The exchange can be accessed from the url https://kraken.com

An account with the exchange is required to obtain the API keys when running this algorithm

This algorithm requires third-party tools, under no circumstances are we affiliated with them. This is the author's personal project

Setting up:
	You need X things:
		1: A kraken account with a non-zero balance in at least one currency with a ticker of 3 letters
		2: The Spyder IDE from Anaconda Inc. which can be found by downloading the Anaconda software through the url https://anaconda.com/download/
		3: API keys from your Kraken account to access your current balances. They are obtainable from your dashboard on the Kraken exchange

Once the API keys obtained, copy them into a text file like the one used for this document
	The public key is to be pasted on the 1st line
	The private key is to be pasted on the 2nd line
	Example:
		-----------------
		- Public Key	-
		- Private Key	-
		-		-
		-		-
		-		-
		-----------------

Once the API keys are pasted correctly, the algorithm is operational in the Spyder IDE

Note that this algorithm cannot execute trades but only displays if there is a possibility of arbitrage opportunity from the latest spot prices of each currency pairs.
The current algorithm does not take into account spreads, slippage, time delay, nor exchange fees. 
While some opportunities appear possible, the user is still responsible for checking over the algorithm's actions to determine if there is an arbitrage opportunity

The author Valentino Magniette-Bosseboeuf cannot be held liable for any damages done by the algorithm or any other third-party tools used